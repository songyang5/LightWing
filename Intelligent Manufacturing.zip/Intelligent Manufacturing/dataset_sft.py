import json
import torch
from torch.utils.data import Dataset

class LightWingSFTDataset(Dataset):
    def __init__(self, file_path, tokenizer, max_length=1024):
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.data = []
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                self.data.append(json.loads(line))

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        item = self.data[idx]
        # 构造拼接格式：指令 + 输入 -> 输出
        prompt = f"Instruction: {item['instruction']}\nInput: {item['input']}\nAnswer: "
        answer = item['output']
        
        # 全文编码
        full_text = prompt + answer + self.tokenizer.eos_token
        encodings = self.tokenizer(full_text, truncation=True, max_length=self.max_length, padding="max_length")
        
        input_ids = torch.tensor(encodings['input_ids'])
        labels = input_ids.clone()
        
        # 屏蔽 Prompt 部分的 Loss 计算 (设置为 -100)
        prompt_ids = self.tokenizer(prompt, truncation=True, max_length=self.max_length)['input_ids']
        labels[:len(prompt_ids)] = -100
        
        return input_ids, labels