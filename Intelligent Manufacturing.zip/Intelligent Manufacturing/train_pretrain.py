import os
import time
import math
import torch
import torch.nn as nn
import numpy as np
from torch.utils.data import DataLoader, Dataset
from transformers import AutoTokenizer

# 导入模型组件
from model.model_im import IMConfig, IMForCausalLM
from trainer.utils import Logger, setup_seed, lm_checkpoint

# --- 1. 高性能二进制数据集 ---
class IMPretrainDataset(Dataset):
    def __init__(self, bin_file, max_length=512):
        self.max_length = max_length
        # 使用 memmap 极速读取，不占内存
        if not os.path.exists(bin_file):
            raise FileNotFoundError(f"找不到二进制语料文件: {bin_file}")
        self.data = np.memmap(bin_file, dtype=np.uint16, mode='r')
        self.num_samples = len(self.data) // max_length

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx):
        start = idx * self.max_length
        end = start + self.max_length
        # 预训练采样 Block
        chunk = torch.from_numpy(self.data[start:end].astype(np.int64))
        return chunk, chunk

# --- 2. 学习率调度策略 (带 Warmup 的余弦退火) ---
def get_lr(it, total_steps, learning_rate, min_lr=1e-5):
    warmup_steps = int(total_steps * 0.05)
    if it < warmup_steps:
        return learning_rate * it / warmup_steps
    if it > total_steps:
        return min_lr
    decay_ratio = (it - warmup_steps) / (total_steps - warmup_steps)
    coeff = 0.5 * (1.0 + math.cos(math.pi * decay_ratio))
    return min_lr + coeff * (learning_rate - min_lr)

# --- 3. 核心训练函数 ---
def train():
    # 基础配置
    setup_seed(42)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # 加载 Tokenizer
    tokenizer_path = './model'
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)
    
    # --- 模型配置 (针对内存优化后的参数) ---
    config = IMConfig(
        vocab_size=len(tokenizer),
        hidden_size=512,            # 适中规模
        num_hidden_layers=12,       # 保证深度以理解工业逻辑
        num_attention_heads=8,
        max_position_embeddings=512 # 缩短序列长度解决内存问题
    )
    
    model = IMForCausalLM(config).to(device)
    Logger(f"模型初始化完成，总参数量统计中...")
    
    # 加载数据
    # 请确保已通过 make_bin.py 将 im_pretrain_corpus.txt 转为 im_pretrain_data.bin
    dataset = IMPretrainDataset("im_pretrain_data.bin", max_length=config.max_position_embeddings)
    train_loader = DataLoader(
        dataset, 
        batch_size=8,      # 根据显存大小可微调 (4-16)
        shuffle=True, 
        num_workers=0,      # Windows 环境建议设为 0
        pin_memory=False
    )

    # 优化器
    learning_rate = 4e-4
    optimizer = torch.optim.AdamW(
        model.parameters(), 
        lr=learning_rate, 
        weight_decay=0.01,
        betas=(0.9, 0.95)
    )
    
    # 混合精度训练加速器
    scaler = torch.cuda.amp.GradScaler()

    epochs = 1
    total_steps = len(train_loader) * epochs
    model.train()
    
    Logger("开始 IMR-LLM 预训练阶段...")
    start_time = time.time()
    
    for epoch in range(epochs):
        for step, (X, Y) in enumerate(train_loader):
            X, Y = X.to(device), Y.to(device)
            
            # 更新学习率
            curr_step = epoch * len(train_loader) + step
            lr = get_lr(curr_step, total_steps, learning_rate)
            for param_group in optimizer.param_groups:
                param_group['lr'] = lr

            # 自动混合精度前向传播
            with torch.cuda.amp.autocast():
                outputs = model(X, labels=Y)
                loss = outputs.loss

            # 反向传播与优化
            optimizer.zero_grad()
            scaler.scale(loss).backward()
            
            # 梯度裁剪：工业文本逻辑复杂，必须限制梯度防止震荡
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            
            scaler.step(optimizer)
            scaler.update()

            # 打印日志
            if step % 20 == 0:
                cost_time = time.time() - start_time
                Logger(f"Epoch: [{epoch}/{epochs}] Step: {step}/{len(train_loader)} "
                       f"Loss: {loss.item():.4f} LR: {lr:.2e} Time: {cost_time:.2f}s")

        # 保存每个 Epoch 的权重
        lm_checkpoint(config, weight=f'IM_pretrain_epoch_{epoch}', model=model, optimizer=optimizer)

    # 最终保存
    lm_checkpoint(config, weight='IM_pretrain_final', model=model, optimizer=optimizer)
    Logger("✅ 预训练任务圆满完成。")

if __name__ == "__main__":
    train()