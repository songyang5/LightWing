"""
IMR-LLM 训练工具函数集合
"""
import os
import sys
import random
import math
import numpy as np
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel
from torch.utils.data import Sampler
from transformers import AutoTokenizer

# 模型引用
from model.model_im import IMForCausalLM

def get_model_params(model, config):
    """
    统计模型参数量，兼容 Dense 和 MoE 结构
    """
    total = sum(p.numel() for p in model.parameters()) / 1e6
    # 针对 IMR-LLM 架构的参数统计
    n_routed = getattr(config, 'n_routed_experts', 0)
    n_active = getattr(config, 'num_experts_per_tok', 0)
    
    # 统计单个专家参数（未来病房可以更改为MoE）
    expert = sum(p.numel() for n, p in model.named_parameters() if 'mlp.experts.0.' in n) / 1e6
    base = total - (expert * n_routed)
    active = base + (expert * n_active)
    
    if active < total: 
        Logger(f'Model Params: {total:.2f}M | Active: {active:.2f}M')
    else: 
        Logger(f'Model Params: {total:.2f}M')

def is_main_process():
    return not dist.is_initialized() or dist.get_rank() == 0

def Logger(content):
    if is_main_process():
        print(f"[IM-LOG] {content}")

def get_lr(current_step, total_steps, lr):
    """
    余弦退火学习率调度
    """
    return lr * (0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * current_step / total_steps)))

def init_distributed_mode():
    if int(os.environ.get("RANK", -1)) == -1:
        return 0  # 单卡模式

    # Windows 环境下建议使用 gloo，Linux 建议使用 nccl
    backend = "nccl" if sys.platform != 'win32' else "gloo"
    dist.init_process_group(backend=backend)
    local_rank = int(os.environ["LOCAL_RANK"])
    torch.cuda.set_device(local_rank)
    return local_rank

def setup_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def lm_checkpoint(lm_config, weight='IM_pretrain', model=None, optimizer=None, epoch=0, step=0, save_dir='./checkpoints', **kwargs):
    """
    保存模型权重与训练状态
    """
    if not is_main_process():
        return
        
    os.makedirs(save_dir, exist_ok=True)
    moe_path = '_moe' if getattr(lm_config, 'use_moe', False) else ''
    ckp_path = f'{save_dir}/{weight}_{lm_config.hidden_size}{moe_path}.pth'
    resume_path = f'{save_dir}/{weight}_resume.pth'

    if model is not None:
        raw_model = model.module if isinstance(model, DistributedDataParallel) else model
        raw_model = getattr(raw_model, '_orig_mod', raw_model)
        
        # 转换为 fp16 存储以节省空间
        state_dict = {k: v.half().cpu() for k, v in raw_model.state_dict().items()}
        torch.save(state_dict, ckp_path)
        
        # 保存断点续训数据
        resume_data = {
            'epoch': epoch,
            'step': step,
            'optimizer': optimizer.state_dict() if optimizer else None,
            'world_size': dist.get_world_size() if dist.is_initialized() else 1,
        }
        torch.save(resume_data, resume_path)
        Logger(f"Checkpoint saved: {ckp_path}")

def init_model(lm_config, from_weight='none', tokenizer_path='./model', device='cuda'):
    """
    初始化 IM 模型并可选加载权重
    """
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)
    model = IMForCausalLM(lm_config)

    if from_weight != 'none':
        if os.path.exists(from_weight):
            weights = torch.load(from_weight, map_location=device)
            model.load_state_dict(weights, strict=False)
            Logger(f"Loaded weights from {from_weight}")

    get_model_params(model, lm_config)
    return model.to(device), tokenizer

# 保持 SkipBatchSampler 不变，用于在训练中断后跳过已训练的 batch
class SkipBatchSampler(Sampler):
    def __init__(self, sampler, batch_size, skip_batches=0):
        self.sampler = sampler
        self.batch_size = batch_size
        self.skip_batches = skip_batches

    def __iter__(self):
        batch = []
        skipped = 0
        for idx in self.sampler:
            batch.append(idx)
            if len(batch) == self.batch_size:
                if skipped < self.skip_batches:
                    skipped += 1
                    batch = []
                    continue
                yield batch
                batch = []
        if len(batch) > 0 and skipped >= self.skip_batches:
            yield batch

    def __len__(self):
        total_batches = (len(self.sampler) + self.batch_size - 1) // self.batch_size
        return max(0, total_batches - self.skip_batches)