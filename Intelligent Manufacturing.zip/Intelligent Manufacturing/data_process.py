import os
import pdfplumber
from tqdm import tqdm
import re

def clean_pdf_text(text):
    # 1. 替换连续换行和多余空格
    text = re.sub(r'\n+', '\n', text)
    text = re.sub(r' +', ' ', text)
    # 2. 去除页码标识
    text = re.sub(r'\n\s*(-?\s*\d+\s*-?|Page\s+\d+)\s*\n', '\n', text)
    # 3. 修正断词
    text = text.replace('-\n', '')
    return text.strip()

def build_im_pretrain_corpus(input_dir, output_txt):
    # 找到文件夹下所有 pdf
    pdf_files = [f for f in os.listdir(input_dir) if f.endswith('.pdf')]
    print(f"在 {input_dir} 中找到 {len(pdf_files)} 个 PDF 文件")
    
    with open(output_txt, 'w', encoding='utf-8') as f_out:
        for file_name in pdf_files:
            file_path = os.path.join(input_dir, file_name)
            print(f"正在解析: {file_name}")
            
            try:
                with pdfplumber.open(file_path) as pdf:
                    for page in tqdm(pdf.pages):
                        content = page.extract_text()
                        if content:
                            cleaned = clean_pdf_text(content)
                            f_out.write(cleaned + "\n")
                
                # 每个文件结束后写入分界符
                f_out.write("\n<|endoftext|>\n")
            except Exception as e:
                print(f"文件 {file_name} 解析出错: {e}")

    print(f"--- 所有语料已存入: {output_txt} ---")

if __name__ == "__main__":
    input_folder = "pre-training corpora"
    target_txt = "im_pretrain_corpus.txt"
    
    build_im_pretrain_corpus(input_folder, target_txt)