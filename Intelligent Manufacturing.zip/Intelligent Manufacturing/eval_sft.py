import torch
from transformers import AutoTokenizer
from model.model_im import IMConfig, IMForCausalLM

def lightwing_inference(model, tokenizer, instruction, env_input, device):
    prompt = f"Instruction: {instruction}\nInput: {env_input}\nAnswer: "
    input_ids = tokenizer.encode(prompt, return_tensors='pt').to(device)
    
    model.eval()
    with torch.no_grad():
        # 
        output_ids = model.generate(
            input_ids, 
            max_new_tokens=256, 
            do_sample=True, 
            top_p=0.85, 
            temperature=0.3 
        )
    
    full_text = tokenizer.decode(output_ids[0], skip_special_tokens=True)
    return full_text.split("Answer: ")[-1]

def run_test():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tokenizer = AutoTokenizer.from_pretrained('./model')
    
    # 加载 SFT 后的模型
    config = IMConfig(vocab_size=len(tokenizer), hidden_size=512, num_hidden_layers=12)
    model = IMForCausalLM(config)
    model.load_state_dict(torch.load('./checkpoints/LightWing_SFT_Final_512.pth', map_location=device))
    model.to(device)

    # 模拟一个工业任务
    test_instruction = "请指挥 H1_Atlas 前往 QC_Station，拾取 Sensor_Kit 并搬运至 Storage_Zone。"
    test_env = "环境资源: [H1_Atlas, Mobile_DualArm_A, Dobot_CR5]; 目标: Sensor_Kit"

    print("\n--- LightWing IMR 任务推理测试 ---")
    result = lightwing_inference(model, tokenizer, test_instruction, test_env, device)
    print(result)

if __name__ == "__main__":
    run_test()