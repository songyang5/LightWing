import torch
import torch.nn.functional as F
from transformers import AutoTokenizer
import os

# 导入模型组件
from model.model_im import IMConfig, IMForCausalLM

def generate(model, tokenizer, prompt, max_new_tokens=100, temperature=0.8, top_p=0.9, device='cuda'):
    """
    自回归生成函数：支持 Top-p 采样和温度调节
    """
    model.eval()
    # 编码输入
    input_ids = tokenizer.encode(prompt, return_tensors='pt').to(device)
    
    with torch.no_grad():
        for _ in range(max_new_tokens):
            # 获取模型输出
            outputs = model(input_ids)
            # 取得最后一个位置的 Logits
            logits = outputs.logits[:, -1, :] 
            
            # 缩放温度 (Temperature Scaling)
            logits = logits / max(temperature, 1e-5)
            
            # --- Top-p (Nucleus) 采样逻辑 ---
            sorted_logits, sorted_indices = torch.sort(logits, descending=True)
            cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
            
            # 移除累积概率超过 top_p 的 token
            sorted_indices_to_remove = cumulative_probs > top_p
            sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
            sorted_indices_to_remove[..., 0] = 0
            
            indices_to_remove = sorted_indices_to_remove.scatter(1, sorted_indices, sorted_indices_to_remove)
            logits[indices_to_remove] = float('-inf')
            
            # 采样下一个 token
            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            
            # 拼接 ID
            input_ids = torch.cat([input_ids, next_token], dim=-1)
            
            # 遇到结束符提前停止
            if next_token.item() == tokenizer.eos_token_id:
                break
                
    return tokenizer.decode(input_ids[0], skip_special_tokens=True)

def run_eval():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # 1. 路径设置 
    # 模型文件名是 IM_pretrain_final_512.pth
    model_weight_path = './checkpoints/IM_pretrain_final_512.pth'
    tokenizer_path = './model'
    
    if not os.path.exists(model_weight_path):
        print(f"❌ 找不到权重文件: {model_weight_path}，请检查路径。")
        return

    # 2. 初始化配置
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)
    config = IMConfig(
        vocab_size=len(tokenizer),
        hidden_size=512,
        num_hidden_layers=12,    
        num_attention_heads=8,
        max_position_embeddings=512
    )
    
    # 3. 加载模型与权重
    model = IMForCausalLM(config)
    
    # 使用 map_location 兼容不同 
    state_dict = torch.load(model_weight_path, map_location=device)
    
    # 自动处理存在的字典嵌套
    if isinstance(state_dict, dict) and 'model' in state_dict:
        state_dict = state_dict['model']
        
    try:
        model.load_state_dict(state_dict)
        model.to(device)
        print(f"✅ 成功加载权重: {model_weight_path}")
        print(f"📊 模型参数量: {sum(p.numel() for p in model.parameters()) / 1e6:.2f} M")
    except Exception as e:
        print(f"❌ 权重加载失败: {e}")
        return

    # 4. 设计符合 IMR 工业背景的测试 Prompt
    test_prompts = [
        "同济大学是",
        "智能制造是"
    ]

    print("\n" + "="*50)
    print("🚀 IMR-LLM 预训练效果评估")
    print("="*50)

    for i, prompt in enumerate(test_prompts):
        print(f"\n【Prompt {i+1}】: {prompt}")
        # 增加 max_new_tokens 可以看更长的生成效果
        generated_text = generate(model, tokenizer, prompt, max_new_tokens=40, device=device)
        print(f"【Generated】: {generated_text}")
        print("-" * 50)

if __name__ == "__main__":
    run_eval()