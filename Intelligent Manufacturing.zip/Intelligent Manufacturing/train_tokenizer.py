import os
import json
from tokenizers import decoders, models, pre_tokenizers, trainers, Tokenizer

# --- 路径配置 ---
# 指向解析 PDF 后生成的纯文本语料
DATA_PATH = './im_pretrain_corpus.txt' 
# 训练好的 Tokenizer 存放位置
TOKENIZER_DIR = './model/' 
# 词表大小：对于垂直领域，6400-8000 足够精简高效
VOCAB_SIZE = 6400 
# 特殊 Token 总预留位
SPECIAL_TOKENS_NUM = 36 

def get_texts(data_path):
    """
    数据迭代器：直接读取生成的 IMR 论文语料
    """
    if not os.path.exists(data_path):
        raise FileNotFoundError(f"找不到语料文件: {data_path}，请先运行 PDF 解析脚本。")
        
    with open(data_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                yield line

def train_tokenizer(data_path, tokenizer_dir, vocab_size, special_tokens_num=SPECIAL_TOKENS_NUM):
    # 1. 初始化 BPE 模型
    tokenizer = Tokenizer(models.BPE())
    # 使用 ByteLevel 预分词，完美支持中英文和特殊工业符号
    tokenizer.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    
    # 2. 定义特殊 Token 列表（保持与IMR 逻辑一致）
    special_tokens_list = [
        "<|endoftext|>", "<|im_start|>", "<|im_end|>", 
        "<|object_ref_start|>", "<|object_ref_end|>", "<|box_start|>", "<|box_end|>", "<|quad_start|>", "<|quad_end|>", 
        "<|vision_start|>", "<|vision_end|>", "<|vision_pad|>", "<|image_pad|>", "<|video_pad|>", 
        "<|audio_start|>", "<|audio_end|>", "<|audio_pad|>", "<tts_pad>", "<tts_text_bos>", "<tts_text_eod>", "<tts_text_bos_single>"
    ]
    
    additional_tokens_list = [
        "<tool_call>", "</tool_call>",
        "<tool_response>", "</tool_response>",
        "<think>", "</think>"
    ]
    
    # 填充预留位 buffer
    num_buffer = special_tokens_num - len(special_tokens_list + additional_tokens_list)
    buffer_tokens = [f"<|buffer{i}|>" for i in range(1, num_buffer + 1)]
    all_special_tokens = special_tokens_list + additional_tokens_list + buffer_tokens

    # 3. 配置训练器
    trainer = trainers.BpeTrainer(
        vocab_size=vocab_size,
        show_progress=True,
        initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),
        special_tokens=all_special_tokens
    )

    # 4. 开始训练
    print(f"正在基于 {data_path} 训练词表...")
    texts = get_texts(data_path)
    tokenizer.train_from_iterator(texts, trainer=trainer)
    
    # 5. 设置解码器
    tokenizer.decoder = decoders.ByteLevel()

    # 6. 保存并导出配置文件
    os.makedirs(tokenizer_dir, exist_ok=True)
    tokenizer.save(os.path.join(tokenizer_dir, "tokenizer.json"))
    
    # --- 关键：生成满足 transformers 库要求的配置文件 ---
    added_tokens_decoder = {}
    for i, token in enumerate(all_special_tokens):
        idx = tokenizer.token_to_id(token)
        added_tokens_decoder[str(idx)] = {
            "content": token,
            "lstrip": False,
            "normalized": False,
            "rstrip": False,
            "single_word": False,
            "special": True if token in special_tokens_list else False
        }

    config = {
        "add_bos_token": False,
        "add_eos_token": False,
        "add_prefix_space": False,
        "added_tokens_decoder": added_tokens_decoder,
        "additional_special_tokens": [t for t in special_tokens_list if t not in ["<|endoftext|>"]],
        "bos_token": "<|im_start|>",
        "eos_token": "<|im_end|>",
        "pad_token": "<|endoftext|>",
        "model_max_length": 131072,
        "tokenizer_class": "PreTrainedTokenizerFast",
        "chat_template": "{% for message in messages %}{{'<|im_start|>' + message['role'] + '\\n' + message['content'] + '<|im_end|>' + '\\n'}}{% endfor %}{% if add_generation_prompt %}{{'<|im_start|>assistant\\n'}}{% endif %}"
    }

    with open(os.path.join(tokenizer_dir, "tokenizer_config.json"), "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=4)
        
    print(f"Tokenizer 训练完成，保存在: {tokenizer_dir}")

def eval_tokenizer(tokenizer_dir):
    """
    验证脚本：确保没有 ModelWrapper 报错
    """
    from transformers import AutoTokenizer
    print("\n--- 正在验证 Tokenizer 有效性 ---")
    try:
        tokenizer = AutoTokenizer.from_pretrained(tokenizer_dir)
        test_text = "IMR-LLM framework with Disjunctive Graphs."
        encoded = tokenizer.encode(test_text)
        decoded = tokenizer.decode(encoded)
        print(f"测试文本: {test_text}")
        print(f"编码 ID: {encoded}")
        print(f"解码文本: {decoded}")
        print("✅ 验证通过！ModelWrapper 报错已解决。")
    except Exception as e:
        print(f"❌ 验证失败: {e}")

if __name__ == '__main__':
    train_tokenizer(DATA_PATH, TOKENIZER_DIR, VOCAB_SIZE)
    eval_tokenizer(TOKENIZER_DIR)