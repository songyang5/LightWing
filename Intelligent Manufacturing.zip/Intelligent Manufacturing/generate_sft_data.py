import json
import random
import os

def generate_lightwing_dataset(num_samples=10000):
    # 1. 机器人与设备定义
    robot_types = {
        "Humanoid": ["H1_Atlas", "H2_Unitree"], # 人形机器人
        "DualArm_Mobile": ["Mobile_DualArm_A", "Mobile_DualArm_B"], # 双臂移动操作机器人
        "Static_Arm": ["Ur5_Arm", "Kuka_LBR"], # 固定式机械臂
        "Dobot": ["Dobot_CR5", "Dobot_M1"] # 越疆机器人
    }
    
    locations = ["Storage_Zone", "Assembly_Line_A", "QC_Station", "Loading_Dock", "Precision_Lab"]
    objects = ["Circuit_Module", "Heavy_Chassis", "Sensor_Kit", "Raw_Material_Box"]
    
    dataset = []

    for i in range(num_samples):
        # 随机组合任务类型
        task_category = random.choice(["dual_arm_heavy", "humanoid_transport", "dobot_qc_delivery", "multi_robot_sync"])
        
        # 基础资源抽样
        r_dual = random.choice(robot_types["DualArm_Mobile"])
        r_human = random.choice(robot_types["Humanoid"])
        r_dobot = random.choice(robot_types["Dobot"])
        r_static = random.choice(robot_types["Static_Arm"])
        obj = random.choice(objects)
        loc_src = random.choice(locations)
        loc_dest = random.choice([l for l in locations if l != loc_src])

        if task_category == "dual_arm_heavy":
            # 场景：双臂移动机器人抓取重物并放置
            instruction = f"请指挥{r_dual}前往{loc_src}，使用双臂协同抓取{obj}并放置到{loc_dest}的装配台上。"
            analysis = (f"- 结合弧: Op1({r_dual}, 导航至{loc_src}) -> Op2({r_dual}, 双臂抓取{obj}) -> Op3({r_dual}, 放置至{loc_dest})。\n"
                        f"- 资源弧: 抓取过程中需保持双臂力矩平衡，独占{loc_src}操作空间。")
            tree = f"ROOT: Sequence(Action: Navigation, Action: DualArm_Grasp, Action: Place)"
            code = (f"def heavy_transfer():\n"
                    f"    {r_dual}.nav_to('{loc_src}')\n"
                    f"    {r_dual}.arm_left.grasp('{obj}')\n"
                    f"    {r_dual}.arm_right.grasp('{obj}')\n"
                    f"    {r_dual}.move_to('{loc_dest}')\n"
                    f"    {r_dual}.release_all()")

        elif task_category == "humanoid_transport":
            # 场景：人形机器人搬运
            instruction = f"要求{r_human}从{loc_src}搬运{obj}到{loc_dest}，注意保持行走姿态稳定。"
            analysis = (f"- 结合弧: Op1({r_human}, 拾取) -> Op2({r_human}, 步行搬运) -> Op3({r_human}, 交付)。\n"
                        f"- 资源弧: 步行路径需避开其他移动机器人。")
            tree = f"ROOT: Sequence(Node: Pick, Node: Humanoid_Walk, Node: Drop)"
            code = (f"def humanoid_task():\n"
                    f"    {r_human}.stand_by('{loc_src}')\n"
                    f"    {r_human}.execute_pick('{obj}')\n"
                    f"    {r_human}.walk_path(target='{loc_dest}', balance_mode='dynamic')\n"
                    f"    {r_human}.place_object()")

        elif task_category == "dobot_qc_delivery":
            # 场景：越疆机器人质检并由双臂机器人送货
            instruction = f"先让{r_dobot}在{loc_src}进行成品质检，合格后由{r_dual}送往{loc_dest}。"
            analysis = (f"- 结合弧: Op1({r_dobot}, 质检) -> Op2({r_dual}, 接驳并送货)。\n"
                        f"- 资源弧: {r_dual}必须在接收到{r_dobot}的QC_PASS信号后才能进入{loc_src}。")
            tree = f"ROOT: Sequence(Node: Dobot_QC, Node: DualArm_Delivery)"
            code = (f"def qc_and_delivery():\n"
                    f"    status = {r_dobot}.inspect('{obj}')\n"
                    f"    if status == 'PASS':\n"
                    f"        {r_dual}.dock_with('{r_dobot}')\n"
                    f"        {r_dual}.transport('{obj}', to='{loc_dest}')")

        else:
            # 场景：多机协同（机械臂抓取 + 越疆机器人送货）
            instruction = f"协调{r_static}将{obj}从传送带抓取至托盘，随后由{r_dobot}负责将托盘送货至{loc_dest}。"
            analysis = (f"- 结合弧: Op1({r_static}, 抓取) -> Op2({r_dobot}, 接收托盘并导航)。\n"
                        f"- 资源弧: 传送带出口处{r_static}与{r_dobot}存在协作交点。")
            tree = f"ROOT: Sequence(Action: Static_Pick, Action: Dobot_AGV_Move)"
            code = (f"def collaborative_flow():\n"
                    f"    {r_static}.pick_from_conveyor('{obj}')\n"
                    f"    {r_static}.place_to_tray(robot_receiver='{r_dobot}')\n"
                    f"    sync_barrier({r_static}, {r_dobot})\n"
                    f"    {r_dobot}.deliver_to('{loc_dest}')")

        sample = {
            "id": i + 1,
            "instruction": instruction,
            "input": f"环境资源: [{r_human}, {r_dual}, {r_dobot}, {r_static}]; 目标: {obj}",
            "output": f"【1. 离散图分析】:\n{analysis}\n【2. 过程树构建】:\n{tree}\n【3. 程序生成】:\n{code}"
        }
        dataset.append(sample)

    # 保存
    output_file = "LightWing_IMR_10000_Full.jsonl"
    with open(output_file, "w", encoding="utf-8") as f:
        for entry in dataset:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    
    print(f"成功生成 {num_samples} 条数据，保存至: {output_file}")

if __name__ == "__main__":
    generate_lightwing_dataset(10000)