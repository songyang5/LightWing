import numpy as np
from transformers import AutoTokenizer
from tqdm import tqdm

def tokenize_to_bin():
    tokenizer_path = './model' # IM Tokenizer 文件夹
    input_txt = 'im_pretrain_corpus.txt'
    output_bin = 'im_pretrain_data.bin'
    
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)
    
    all_ids = []
    
    with open(input_txt, 'r', encoding='utf-8') as f:
        # 对于大文件，建议逐行读取
        for line in tqdm(f, desc="Tokenizing"):
            line = line.strip()
            if not line: continue
            
            # 使用 encode 转化为 token ID
            ids = tokenizer.encode(line, add_special_tokens=False)
            all_ids.extend(ids)
    
    # 转换为 uint16 节省存储（前提是词表大小 < 65535）
    ids_array = np.array(all_ids, dtype=np.uint16)
    with open(output_bin, 'wb') as f:
        f.write(ids_array.tobytes())
    
    print(f"成功生成二进制预训练文件！Token 总数: {len(ids_array)}")

if __name__ == "__main__":
    tokenize_to_bin()