import torch
from torch.utils.data import DataLoader
from transformers import AutoTokenizer
from model.model_im import IMConfig, IMForCausalLM
from trainer.utils import Logger, setup_seed, lm_checkpoint
from dataset_sft import LightWingSFTDataset

def train_sft():
    setup_seed(42)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # 1. 加载预训练好的模型权重
    tokenizer_path = './model'
    pretrain_weight_path = './checkpoints/IM_pretrain_final_512.pth'
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)
    
    config = IMConfig(
        vocab_size=len(tokenizer),
        hidden_size=512,
        num_hidden_layers=12,
        num_attention_heads=8,
        max_position_embeddings=1024 
    )
    
    model = IMForCausalLM(config)
    # 加载预训练状态
    ckpt = torch.load(pretrain_weight_path, map_location=device)
    model.load_state_dict(ckpt.get('model', ckpt), strict=False)
    model.to(device)
    Logger(f"已加载预训练权重，开始 SFT 微调...")

    # 2. 准备数据集
    dataset = LightWingSFTDataset("LightWing_IMR_10000_Full.jsonl", tokenizer, max_length=1024)
    train_loader = DataLoader(dataset, batch_size=4, shuffle=True)

    # 3. 优化器：SFT 使用较小的学习率 
    optimizer = torch.optim.AdamW(model.parameters(), lr=5e-5)
    scaler = torch.cuda.amp.GradScaler()

    model.train()
    for epoch in range(3): 
        for step, (input_ids, labels) in enumerate(train_loader):
            input_ids, labels = input_ids.to(device), labels.to(device)
            
            with torch.cuda.amp.autocast():
                outputs = model(input_ids, labels=labels)
                loss = outputs.loss

            optimizer.zero_grad()
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            if step % 10 == 0:
                Logger(f"Epoch: {epoch} | Step: {step} | Loss: {loss.item():.4f}")

    # 保存 SFT 后的模型
    lm_checkpoint(config, weight='LightWing_SFT_Final', model=model, optimizer=optimizer)
    Logger("SFT 微调完成。")

if __name__ == "__main__":
    train_sft()